let array=[1,2,3,4,5,6,7,8,9];
console.log("Original array");

for (let text of array)
{
    console.log(text);
}

console.log("Product of array");

const Product=array.reduce((res,curr)=>{
    return res*curr;
});

console.log(Product);