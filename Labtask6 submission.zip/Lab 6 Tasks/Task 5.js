function countVowels(v)
{
    let count=0;

    for (let countV of v)
    {
        if(countV=='a'|| countV=='e'|| countV=='i' || countV=='o' ||countV=='u'|| 
            countV=='A'|| countV=='E'|| countV=='I' ||countV=='O'||countV=='U')
            count++;
    }
    return count;
}

let Result=countVowels("Saira");

console.log("Vowels in string are:"+Result);