let array =[32,89,76,54,21];

console.log("Original array:");
for(let text1 of array)
{
console.log(text1);
}

console.log("Filtering out marks greater than 50");

let marksGreater=array.filter((marks)=>
{
    return marks>50;
});

console.log(marksGreater);
