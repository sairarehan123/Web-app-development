let n=prompt("Enter a number");

let array=[];

for(let i=1;i<=n;i++)
{
    array.push(i);
}

console.log(array);