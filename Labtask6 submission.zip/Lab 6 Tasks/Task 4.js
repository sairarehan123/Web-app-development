let array=["Code Nest","Soft Wave","Tech Hive","DevSphere"];
console.log("Original Array:");
for(let text1 of array)
{
    console.log(text1);
}


console.log("Removing the first name :");

array.shift();

for(let text2 of array)
{
    console.log(text2);
}

console.log("Removal from mid & addition at mid as well:");
array.splice(1,1,"ByteCrafters");

for(let text3 of array)
{
    console.log(text3);

}

console.log("Adding name at end:");
array.push("Systems limited");

for(let text4 of array)
{
    console.log(text4);
}