let array=["apple","mango","grapes","cherry"];

for (let key of array)
{
    console.log(key.toUpperCase());
}