let array=[7,5,98,65,3,77,11,32];
let min=array[0];
let max=array[0];

for(let num of array)
{
    if(num<min)
    {
        min=num;
    }

    if(num>max)
    {
        max=num;
    }
}

console.log("Smaller Number:"+min);
console.log("Largerst Number:"+max);
