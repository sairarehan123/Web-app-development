let array=[9,8,7,6,5,4,];
console.log("Original Array")

for (let num of array)
{
    console.log(num);
}

console.log("Squares:")

array.forEach(function findsquare(valNum)
{
    console.log(valNum*valNum);
});
