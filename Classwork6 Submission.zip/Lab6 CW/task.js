
/*Arrays*/
let name=["Saira","Amna"];
console.log(typeof name);

let heroes =["ironman","hulk","thor","batman"];
console.log(typeof heroes);

let marks=[98,87,65];
console.log(typeof marks);

let info=["saira",89,"Pakistan"];
console.log(typeof info);

/*for of loop*/
let text="Hello";

for(let char of text){
    console.log(char);
}

let Marks = [85, 76, 98, 43, 21];

let sum = 0;

for (let val of Marks) {
    sum += val;
}

let avg = sum / Marks.length; 

console.log(`Avg marks of class = ${avg}`); 


/*For loop */
for(let i=1;i<=5;i++)
{
    console.log("Iteration i:",i);
}

/* Do While Loop*/
let count=1;
do{
    console.log("Count",count)
    count++;
}while(count<=5);

/*while loop*/

let num=1;
while(num<=5)
{
    console.log("Number:",num)
    num++;
}


/*to string */

let items=["Pen","page","ink","highlighter"];
console.log(items.toString());


/*concat */
let solids=["Chair","table","Cupboard"];
let liquids=["Water","Juice","Milk"];

let solidsliquids=solids.concat(liquids);
console.log(solidsliquids);

/*unshift */

let numbersArray=[1,2,3,4];
for(let num of numbersArray)
{
    console.log(num)
}

numbersArray.unshift(0);
for (let num of numbersArray)
{
    console.log(num);
}

/* shift */

numbersArray.shift();
for(let num of numbersArray)
{
    console.log(num);
}

/* slice */


let arrayNames=["Saira","Zahra","Ayesha","Manahil","Anaya"];
console.log(arrayNames.slice(1,4));


/* splice */
//removing 
let arrNum=[1,2,3,4,5];
arrNum.splice(1,3);
console.log(arrNum);

//replacing the first three numbers
let arrNum1=[1,2,3,4,5,6,7,8,9];
arrNum1.splice(0,3,10,11,12);
console.log(arrNum1);

// Printing numbers using forEach
let arrNum2 = [10, 11, 12, 13, 14, 15];

arrNum2.forEach(function printNumbers(valNum) {
    console.log(valNum);
});

// Uppercase conversion
let arrCity = ["islambad", "multan", "lahore"];

arrCity.forEach(function upper(arrCval) {
    console.log(arrCval.toUpperCase());
});

/* Arrow functions */

// Simple arrow function
const Hello = () => {
    console.log("Hello!!!");
};
Hello();

// Sum using arrow function
const arrowSum = (a, b) => {
    return a + b;
};
console.log("Sum= " + arrowSum(7, 8));


/* reduce method */

let arrNum3=[1,2,3,4,5];
const output = arrNum3.reduce((res,curr) =>
{
    return res + curr;
});

console.log("Sum: " + output);

//finding largest value

let arrNum4=[6,7,9,3,2,9,0];
const outputLargest= arrNum4.reduce((prev , curr) =>
{
    return prev > curr ? prev:curr;
});

console.log("Largest: " + outputLargest);



/* filter method */

let arrNum5=[1,2,3,4,5,6,7,8,9];
let evenArr= arrNum5.filter((evenNum) =>
{
    return evenNum %2==0;
});

console.log("Even Numbers: "+ evenArr);


/* map method */

let arrNum6=[2,3,4];

let newArray= arrNum6.map((numSq) =>
{
    return numSq * numSq;
});

console.log(newArray);