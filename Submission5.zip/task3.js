const Profile=
{
username:"sairarehan5",
profileName:"Saira",
followers:147,
following:348,
posts:0,
};

console.log("Username:"+Profile.username);
console.log("Profile Name:"+Profile.profileName);
console.log("Followers:"+Profile.followers);
console.log("Following:"+Profile.following);
console.log("Posts:"+Profile.posts);