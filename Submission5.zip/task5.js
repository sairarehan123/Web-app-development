let num=prompt("Enter a number");

if(num%3==0){
    console.log("Multiple of 3");
}

else{
    console.log("Not a multiple");
}